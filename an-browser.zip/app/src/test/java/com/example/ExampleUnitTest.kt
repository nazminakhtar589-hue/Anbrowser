package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun browserTab_homeStatus_isAccurate() {
    val homeTab = com.example.model.BrowserTab(url = "home", title = "New Tab")
    assertTrue(homeTab.isHome)
    assertEquals(com.example.model.SecurityStatus.HOME, homeTab.securityStatus)

    val secureTab = com.example.model.BrowserTab(url = "https://example.com", title = "Example")
    assertFalse(secureTab.isHome)
    assertEquals(com.example.model.SecurityStatus.SECURE, secureTab.securityStatus)
  }
}
