package com.example.model

import java.util.UUID

enum class SecurityStatus {
    HOME,
    SECURE,
    INSECURE
}

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "New Tab",
    val url: String = "home",
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isIncognito: Boolean = false,
    val isDesktopMode: Boolean = false
) {
    val isHome: Boolean
        get() = url == "home" || url.isBlank()

    val securityStatus: SecurityStatus
        get() = when {
            isHome -> SecurityStatus.HOME
            url.startsWith("https://", ignoreCase = true) -> SecurityStatus.SECURE
            else -> SecurityStatus.INSECURE
        }

    val displayTitle: String
        get() = when {
            isHome -> if (isIncognito) "Private Tab" else "New Tab"
            title.isNotBlank() && title != "about:blank" -> title
            else -> try {
                android.net.Uri.parse(url).host ?: url
            } catch (e: Exception) {
                url
            }
        }
}
