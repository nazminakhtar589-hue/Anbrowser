package com.example.model

data class QuickShortcut(
    val id: String,
    val title: String,
    val url: String,
    val iconLetter: String = title.firstOrNull()?.uppercase() ?: "W",
    val colorHex: Long = 0xFF1A73E8
) {
    companion object {
        val defaultShortcuts = listOf(
            QuickShortcut("1", "Google", "https://www.google.com", "G", 0xFF4285F4),
            QuickShortcut("2", "YouTube", "https://www.youtube.com", "Y", 0xFFFF0000),
            QuickShortcut("3", "Wikipedia", "https://www.wikipedia.org", "W", 0xFF333333),
            QuickShortcut("4", "GitHub", "https://github.com", "GH", 0xFF24292E),
            QuickShortcut("5", "Reddit", "https://www.reddit.com", "R", 0xFFFF4500),
            QuickShortcut("6", "BBC News", "https://www.bbc.com/news", "B", 0xFFBB1919),
            QuickShortcut("7", "DuckDuckGo", "https://duckduckgo.com", "D", 0xFFDE5833),
            QuickShortcut("8", "Amazon", "https://www.amazon.com", "A", 0xFFFF9900)
        )
    }
}
