package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BrowserTab
import com.example.model.SecurityStatus
import com.example.ui.theme.IncognitoPurple
import com.example.ui.theme.SecureGreen
import com.example.ui.theme.StarGold
import com.example.viewmodel.BrowserPanel

@Composable
fun BrowserTopBar(
    activeTab: BrowserTab,
    isBookmarked: Boolean,
    isDarkTheme: Boolean,
    onNavigateBack: () -> Unit,
    onNavigateForward: () -> Unit,
    onReload: () -> Unit,
    onStopLoading: () -> Unit,
    onGoHome: () -> Unit,
    onLoadUrl: (String) -> Unit,
    onToggleBookmark: () -> Unit,
    onOpenPanel: (BrowserPanel) -> Unit,
    onOpenFindInPage: () -> Unit,
    onToggleDesktopMode: () -> Unit,
    onToggleIncognito: () -> Unit,
    onToggleTheme: () -> Unit,
    onShareUrl: () -> Unit,
    modifier: Modifier = Modifier
) {
    var textFieldValue by remember {
        mutableStateOf(
            TextFieldValue(
                text = if (activeTab.isHome) "" else activeTab.url
            )
        )
    }
    var isFocused by remember { mutableStateOf(false) }
    var menuExpanded by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    val focusRequester = remember { FocusRequester() }

    // Synchronize text field when active tab URL changes and not actively typing
    LaunchedEffect(activeTab.url, isFocused) {
        if (!isFocused) {
            val newText = if (activeTab.isHome) "" else activeTab.url
            textFieldValue = TextFieldValue(text = newText, selection = TextRange(newText.length))
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 3.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Back Button
                IconButton(
                    onClick = onNavigateBack,
                    enabled = activeTab.canGoBack || !activeTab.isHome,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = if (activeTab.canGoBack || !activeTab.isHome) {
                            MaterialTheme.colorScheme.onSurface
                        } else {
                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Forward Button
                IconButton(
                    onClick = onNavigateForward,
                    enabled = activeTab.canGoForward,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("forward_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Forward",
                        tint = if (activeTab.canGoForward) {
                            MaterialTheme.colorScheme.onSurface
                        } else {
                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Reload or Stop Loading
                IconButton(
                    onClick = {
                        if (activeTab.isLoading) onStopLoading() else onReload()
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("reload_button")
                ) {
                    Icon(
                        imageVector = if (activeTab.isLoading) Icons.Default.Close else Icons.Default.Refresh,
                        contentDescription = if (activeTab.isLoading) "Stop" else "Reload",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Home Button
                IconButton(
                    onClick = onGoHome,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("home_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = "Home",
                        tint = if (activeTab.isHome) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Address & Search Bar
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 10.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Security / Incognito / Search indicator
                        val indicatorIcon = when {
                            activeTab.isIncognito -> Icons.Default.Security
                            activeTab.securityStatus == SecurityStatus.SECURE -> Icons.Default.Lock
                            activeTab.isHome -> Icons.Default.Search
                            else -> Icons.Default.Search
                        }
                        val indicatorTint = when {
                            activeTab.isIncognito -> IncognitoPurple
                            activeTab.securityStatus == SecurityStatus.SECURE -> SecureGreen
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }

                        Icon(
                            imageVector = indicatorIcon,
                            contentDescription = "Security Status",
                            tint = indicatorTint,
                            modifier = Modifier
                                .size(16.dp)
                                .padding(end = 4.dp)
                        )

                        // Input field
                        BasicTextField(
                            value = textFieldValue,
                            onValueChange = { textFieldValue = it },
                            singleLine = true,
                            textStyle = TextStyle(
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp
                            ),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    val text = textFieldValue.text.trim()
                                    if (text.isNotBlank()) {
                                        onLoadUrl(text)
                                    }
                                    focusManager.clearFocus()
                                }
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .focusRequester(focusRequester)
                                .onFocusChanged { state ->
                                    isFocused = state.isFocused
                                    if (state.isFocused && textFieldValue.text.isNotEmpty()) {
                                        // Select all text on tap for easy replacement
                                        textFieldValue = textFieldValue.copy(
                                            selection = TextRange(0, textFieldValue.text.length)
                                        )
                                    }
                                }
                                .testTag("address_input"),
                            decorationBox = { innerTextField ->
                                if (textFieldValue.text.isEmpty()) {
                                    Text(
                                        text = "Search Google or type a URL",
                                        style = TextStyle(
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                            fontSize = 13.sp
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                innerTextField()
                            }
                        )

                        // Clear or Star Bookmark Button
                        if (isFocused && textFieldValue.text.isNotEmpty()) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear input",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .size(18.dp)
                                    .clickable {
                                        textFieldValue = TextFieldValue("")
                                    }
                            )
                        } else if (!activeTab.isHome) {
                            Icon(
                                imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                contentDescription = if (isBookmarked) "Bookmarked" else "Bookmark this page",
                                tint = if (isBookmarked) StarGold else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .size(18.dp)
                                    .clickable { onToggleBookmark() }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Overflow Menu
                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("menu_more_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More Options",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Bookmarks") },
                            leadingIcon = { Icon(Icons.Default.Star, contentDescription = null, tint = StarGold) },
                            onClick = {
                                menuExpanded = false
                                onOpenPanel(BrowserPanel.BOOKMARKS)
                            },
                            modifier = Modifier.testTag("menu_bookmarks")
                        )

                        DropdownMenuItem(
                            text = { Text("History") },
                            leadingIcon = { Icon(Icons.Default.History, contentDescription = null) },
                            onClick = {
                                menuExpanded = false
                                onOpenPanel(BrowserPanel.HISTORY)
                            },
                            modifier = Modifier.testTag("menu_history")
                        )

                        DropdownMenuItem(
                            text = { Text("Downloads") },
                            leadingIcon = { Icon(Icons.Default.Download, contentDescription = null) },
                            onClick = {
                                menuExpanded = false
                                onOpenPanel(BrowserPanel.DOWNLOADS)
                            },
                            modifier = Modifier.testTag("menu_downloads")
                        )

                        HorizontalDivider()

                        DropdownMenuItem(
                            text = { Text(if (activeTab.isIncognito) "Exit Incognito" else "New Incognito Tab") },
                            leadingIcon = { Icon(Icons.Default.Security, contentDescription = null, tint = IncognitoPurple) },
                            onClick = {
                                menuExpanded = false
                                onToggleIncognito()
                            },
                            modifier = Modifier.testTag("menu_incognito")
                        )

                        DropdownMenuItem(
                            text = {
                                Text(if (activeTab.isDesktopMode) "Mobile Site" else "Desktop Site")
                            },
                            leadingIcon = {
                                Icon(Icons.Default.Computer, contentDescription = null, tint = if (activeTab.isDesktopMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                            },
                            onClick = {
                                menuExpanded = false
                                onToggleDesktopMode()
                            },
                            modifier = Modifier.testTag("menu_desktop_site")
                        )

                        if (!activeTab.isHome) {
                            DropdownMenuItem(
                                text = { Text("Find in Page") },
                                leadingIcon = { Icon(Icons.Default.FindInPage, contentDescription = null) },
                                onClick = {
                                    menuExpanded = false
                                    onOpenFindInPage()
                                },
                                modifier = Modifier.testTag("menu_find_in_page")
                            )

                            DropdownMenuItem(
                                text = { Text("Share Page") },
                                leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) },
                                onClick = {
                                    menuExpanded = false
                                    onShareUrl()
                                },
                                modifier = Modifier.testTag("menu_share")
                            )
                        }

                        HorizontalDivider()

                        DropdownMenuItem(
                            text = { Text(if (isDarkTheme) "Light Theme" else "Dark Theme") },
                            leadingIcon = {
                                Icon(if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = null)
                            },
                            onClick = {
                                menuExpanded = false
                                onToggleTheme()
                            },
                            modifier = Modifier.testTag("menu_toggle_theme")
                        )

                        DropdownMenuItem(
                            text = { Text("Settings") },
                            leadingIcon = { Icon(Icons.Default.MoreVert, contentDescription = null) },
                            onClick = {
                                menuExpanded = false
                                onOpenPanel(BrowserPanel.SETTINGS)
                            },
                            modifier = Modifier.testTag("menu_settings")
                        )
                    }
                }
            }

            // Progress Bar
            AnimatedVisibility(
                visible = activeTab.isLoading,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                LinearProgressIndicator(
                    progress = { (activeTab.progress.coerceIn(5, 100)) / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.5.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
    }
}
