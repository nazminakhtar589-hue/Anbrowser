package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AN Browser Brand Palette
val BrandBlue = Color(0xFF1A73E8)
val BrandBlueDark = Color(0xFF8AB4F8)
val BrandCyan = Color(0xFF00B4D8)
val BrandNavy = Color(0xFF0A192F)

// Light Theme Colors
val LightBg = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEDF2F7)
val LightBorder = Color(0xFFDADCE0)
val LightTextPrimary = Color(0xFF1F2937)
val LightTextSecondary = Color(0xFF5F6368)

// Dark Theme Colors
val DarkBg = Color(0xFF13171F)
val DarkSurface = Color(0xFF1E2430)
val DarkSurfaceVariant = Color(0xFF283142)
val DarkBorder = Color(0xFF384358)
val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)

// Accent & Status Colors
val IncognitoPurple = Color(0xFF8B5CF6)
val IncognitoDarkBg = Color(0xFF0F172A)
val SecureGreen = Color(0xFF10B981)
val InsecureRed = Color(0xFFEF4444)
val StarGold = Color(0xFFF59E0B)
