package com.example.ui.screens

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.view.ViewGroup
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.BrowserTab
import com.example.viewmodel.BrowserViewModel
import com.example.viewmodel.WebCommand
import kotlinx.coroutines.flow.collectLatest

private const val DESKTOP_USER_AGENT =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(
    tab: BrowserTab,
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Remember or create WebView
    val webView = remember(tab.id) {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            }

            // Set Find Listener for in-page search
            setFindListener { activeMatchOrdinal, numberOfMatches, _ ->
                viewModel.updateFindResult(activeMatchOrdinal, numberOfMatches)
            }

            // Set Download Listener
            setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
                val fileName = URLUtil.guessFileName(url, contentDisposition, mimetype)
                try {
                    val request = DownloadManager.Request(Uri.parse(url)).apply {
                        setMimeType(mimetype)
                        addRequestHeader("User-Agent", userAgent)
                        setDescription("Downloading file via AN Browser...")
                        setTitle(fileName)
                        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                    }
                    val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
                    dm?.enqueue(request)
                    Toast.makeText(context, "Downloading $fileName", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }

                viewModel.recordDownload(fileName, url, mimetype, contentLength)
            }
        }
    }

    // Configure cache and incognito settings
    LaunchedEffect(tab.isIncognito) {
        if (tab.isIncognito) {
            webView.settings.cacheMode = WebSettings.LOAD_NO_CACHE
            webView.clearCache(true)
        } else {
            webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        }
    }

    // Configure Desktop vs Mobile mode
    LaunchedEffect(tab.isDesktopMode) {
        if (tab.isDesktopMode) {
            webView.settings.userAgentString = DESKTOP_USER_AGENT
            webView.settings.useWideViewPort = true
            webView.settings.loadWithOverviewMode = true
        } else {
            webView.settings.userAgentString = null // Reset to default
        }
    }

    // Configure WebChromeClient and WebViewClient
    DisposableEffect(tab.id) {
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                viewModel.onProgressChanged(tab.id, newProgress)
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                super.onReceivedTitle(view, title)
                if (!title.isNullOrBlank()) {
                    viewModel.onTitleReceived(tab.id, title)
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (!url.isNullOrBlank()) {
                    viewModel.onPageStarted(tab.id, url)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (!url.isNullOrBlank()) {
                    viewModel.onPageFinished(
                        tabId = tab.id,
                        url = url,
                        canGoBack = view?.canGoBack() ?: false,
                        canGoForward = view?.canGoForward() ?: false
                    )
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val requestUrl = request?.url?.toString() ?: return false
                if (requestUrl.startsWith("http://") || requestUrl.startsWith("https://")) {
                    return false // Let WebView load it
                }
                // Handle external protocols (tel, mailto, etc)
                return try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(requestUrl))
                    context.startActivity(intent)
                    true
                } catch (e: Exception) {
                    true
                }
            }
        }

        onDispose {
            // Clean up clients
            webView.stopLoading()
        }
    }

    // Load initial URL if not home and hasn't loaded yet
    LaunchedEffect(tab.url) {
        if (tab.url != "home" && tab.url.isNotBlank() && webView.url != tab.url) {
            webView.loadUrl(tab.url)
        }
    }

    // Collect WebCommands
    LaunchedEffect(tab.id) {
        viewModel.webCommands.collectLatest { command ->
            when (command) {
                is WebCommand.LoadUrl -> {
                    if (command.tabId == tab.id) {
                        webView.loadUrl(command.url)
                    }
                }
                is WebCommand.GoBack -> {
                    if (command.tabId == tab.id) {
                        if (webView.canGoBack()) {
                            webView.goBack()
                        } else {
                            viewModel.goHomeActiveTab()
                        }
                    }
                }
                is WebCommand.GoForward -> {
                    if (command.tabId == tab.id && webView.canGoForward()) {
                        webView.goForward()
                    }
                }
                is WebCommand.Reload -> {
                    if (command.tabId == tab.id) {
                        webView.reload()
                    }
                }
                is WebCommand.StopLoading -> {
                    if (command.tabId == tab.id) {
                        webView.stopLoading()
                    }
                }
                is WebCommand.FindInPage -> {
                    webView.findAllAsync(command.query)
                }
                is WebCommand.FindNext -> {
                    webView.findNext(true)
                }
                is WebCommand.FindPrevious -> {
                    webView.findNext(false)
                }
                is WebCommand.ClearMatches -> {
                    webView.clearMatches()
                }
            }
        }
    }

    AndroidView(
        factory = { webView },
        modifier = modifier.fillMaxSize()
    )
}
