package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.BrowserTabStrip
import com.example.ui.components.BrowserTopBar
import com.example.ui.components.FindInPageBar
import com.example.ui.screens.BookmarksSheet
import com.example.ui.screens.DownloadsSheet
import com.example.ui.screens.HistorySheet
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsDialog
import com.example.ui.screens.TabSwitcherSheet
import com.example.ui.screens.WebViewScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.BrowserPanel
import com.example.viewmodel.BrowserViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: BrowserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle external web intent
        intent?.dataString?.let { url ->
            viewModel.createTab(url = url, isIncognito = false)
        }

        setContent {
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            val isDarkTheme = when (themeMode) {
                "Light" -> false
                "Dark" -> true
                else -> isSystemInDarkTheme()
            }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                BrowserApp(
                    viewModel = viewModel,
                    isDarkTheme = isDarkTheme,
                    onToggleTheme = {
                        val nextMode = if (isDarkTheme) "Light" else "Dark"
                        viewModel.setThemeMode(nextMode)
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.dataString?.let { url ->
            viewModel.createTab(url = url, isIncognito = false)
        }
    }
}

@Composable
fun BrowserApp(
    viewModel: BrowserViewModel,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit
) {
    val context = LocalContext.current
    val tabs by viewModel.tabs.collectAsStateWithLifecycle()
    val activeTabId by viewModel.activeTabId.collectAsStateWithLifecycle()
    val activePanel by viewModel.activePanel.collectAsStateWithLifecycle()
    val isFindInPageOpen by viewModel.isFindInPageOpen.collectAsStateWithLifecycle()
    val findQuery by viewModel.findQuery.collectAsStateWithLifecycle()
    val findResult by viewModel.findResult.collectAsStateWithLifecycle()

    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val downloads by viewModel.downloads.collectAsStateWithLifecycle()
    val shortcuts by viewModel.shortcuts.collectAsStateWithLifecycle()
    val searchEngine by viewModel.searchEngine.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()

    val activeTab = tabs.find { it.id == activeTabId } ?: tabs.firstOrNull() ?: return
    val isCurrentBookmarked = viewModel.isCurrentPageBookmarked(activeTab.url)

    // Android Hardware / Gesture Back Navigation Handler
    val canGoBack = activePanel != BrowserPanel.NONE ||
            isFindInPageOpen ||
            activeTab.canGoBack ||
            !activeTab.isHome ||
            tabs.size > 1

    BackHandler(enabled = canGoBack) {
        when {
            activePanel != BrowserPanel.NONE -> viewModel.closePanel()
            isFindInPageOpen -> viewModel.closeFindInPage()
            activeTab.canGoBack -> viewModel.goBackActiveTab()
            !activeTab.isHome -> viewModel.goHomeActiveTab()
            tabs.size > 1 -> viewModel.closeTab(activeTab.id)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Column {
                // Tab strip with all open tabs
                BrowserTabStrip(
                    tabs = tabs,
                    activeTabId = activeTabId,
                    onTabSelected = { viewModel.switchTab(it) },
                    onCloseTab = { viewModel.closeTab(it) },
                    onNewTab = { viewModel.createTab(url = "home", isIncognito = activeTab.isIncognito) },
                    onOpenTabSwitcher = { viewModel.openPanel(BrowserPanel.TABS_SWITCHER) }
                )

                // Top navigation & address bar
                BrowserTopBar(
                    activeTab = activeTab,
                    isBookmarked = isCurrentBookmarked,
                    isDarkTheme = isDarkTheme,
                    onNavigateBack = { viewModel.goBackActiveTab() },
                    onNavigateForward = { viewModel.goForwardActiveTab() },
                    onReload = { viewModel.reloadActiveTab() },
                    onStopLoading = { viewModel.stopActiveTabLoading() },
                    onGoHome = { viewModel.goHomeActiveTab() },
                    onLoadUrl = { viewModel.loadUrl(it) },
                    onToggleBookmark = { viewModel.toggleBookmarkCurrentPage() },
                    onOpenPanel = { viewModel.openPanel(it) },
                    onOpenFindInPage = { viewModel.openFindInPage() },
                    onToggleDesktopMode = { viewModel.toggleDesktopMode(activeTab.id) },
                    onToggleIncognito = { viewModel.toggleIncognitoForCurrentTab() },
                    onToggleTheme = onToggleTheme,
                    onShareUrl = {
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            putExtra(Intent.EXTRA_TEXT, activeTab.url)
                            type = "text/plain"
                        }
                        val shareIntent = Intent.createChooser(sendIntent, "Share link via")
                        context.startActivity(shareIntent)
                    }
                )

                // Find in page bar if activated
                if (isFindInPageOpen && !activeTab.isHome) {
                    FindInPageBar(
                        query = findQuery,
                        matchIndex = findResult.first,
                        matchCount = findResult.second,
                        onQueryChange = { viewModel.updateFindQuery(it) },
                        onNext = { viewModel.findNext() },
                        onPrevious = { viewModel.findPrevious() },
                        onClose = { viewModel.closeFindInPage() }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (activeTab.isHome) {
                HomeScreen(
                    tab = activeTab,
                    shortcuts = shortcuts,
                    bookmarksCount = bookmarks.size,
                    historyCount = history.size,
                    downloadsCount = downloads.size,
                    searchEngine = searchEngine,
                    onSearchOrNavigate = { viewModel.loadUrl(it) },
                    onOpenPanel = { viewModel.openPanel(it) },
                    onAddShortcut = { title, url -> viewModel.addShortcut(title, url) },
                    onRemoveShortcut = { id -> viewModel.removeShortcut(id) },
                    onNewIncognitoTab = { viewModel.createTab(url = "home", isIncognito = true) }
                )
            } else {
                WebViewScreen(
                    tab = activeTab,
                    viewModel = viewModel
                )
            }
        }
    }

    // Panels and Dialogs
    when (activePanel) {
        BrowserPanel.TABS_SWITCHER -> {
            TabSwitcherSheet(
                tabs = tabs,
                activeTabId = activeTabId,
                onTabSelected = { viewModel.switchTab(it) },
                onCloseTab = { viewModel.closeTab(it) },
                onNewTab = { isIncognito -> viewModel.createTab(url = "home", isIncognito = isIncognito) },
                onCloseAll = { incognitoOnly -> viewModel.closeAllTabs(incognitoOnly = incognitoOnly) },
                onDismiss = { viewModel.closePanel() }
            )
        }

        BrowserPanel.BOOKMARKS -> {
            BookmarksSheet(
                bookmarks = bookmarks,
                onSelectBookmark = { viewModel.loadUrl(it) },
                onOpenInNewTab = { viewModel.createTab(url = it, isIncognito = activeTab.isIncognito) },
                onDeleteBookmark = { viewModel.removeBookmark(it) },
                onDismiss = { viewModel.closePanel() }
            )
        }

        BrowserPanel.HISTORY -> {
            HistorySheet(
                history = history,
                onSelectHistory = { viewModel.loadUrl(it) },
                onDeleteHistoryItem = { viewModel.removeHistoryItem(it) },
                onClearAllHistory = { viewModel.clearAllHistory() },
                onDismiss = { viewModel.closePanel() }
            )
        }

        BrowserPanel.DOWNLOADS -> {
            DownloadsSheet(
                downloads = downloads,
                onDeleteDownload = { viewModel.removeDownload(it) },
                onClearAllDownloads = { viewModel.clearAllDownloads() },
                onDismiss = { viewModel.closePanel() }
            )
        }

        BrowserPanel.SETTINGS -> {
            SettingsDialog(
                searchEngine = searchEngine,
                themeMode = themeMode,
                onSearchEngineSelected = { viewModel.setSearchEngine(it) },
                onThemeModeSelected = { viewModel.setThemeMode(it) },
                onClearHistory = { viewModel.clearAllHistory() },
                onDismiss = { viewModel.closePanel() }
            )
        }

        BrowserPanel.NONE -> {
            // Nothing to show
        }
    }
}
