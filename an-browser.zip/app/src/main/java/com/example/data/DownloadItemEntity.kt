package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloads")
data class DownloadItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fileName: String,
    val url: String,
    val mimeType: String? = null,
    val contentLength: Long = 0L,
    val downloadedAt: Long = System.currentTimeMillis()
)
