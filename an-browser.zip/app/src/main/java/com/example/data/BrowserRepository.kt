package com.example.data

import kotlinx.coroutines.flow.Flow

class BrowserRepository(private val dao: BrowserDao) {
    // Bookmarks
    val bookmarks: Flow<List<BookmarkEntity>> = dao.getAllBookmarks()

    suspend fun isBookmarked(url: String): Boolean {
        return dao.getBookmarkByUrl(url) != null
    }

    suspend fun addBookmark(title: String, url: String): Long {
        return dao.insertBookmark(
            BookmarkEntity(
                title = title.ifBlank { url },
                url = url
            )
        )
    }

    suspend fun removeBookmarkById(id: Long) {
        dao.deleteBookmarkById(id)
    }

    suspend fun removeBookmarkByUrl(url: String) {
        dao.deleteBookmarkByUrl(url)
    }

    // History
    val history: Flow<List<HistoryEntity>> = dao.getAllHistory()

    suspend fun addHistory(title: String, url: String): Long {
        return dao.insertHistory(
            HistoryEntity(
                title = title.ifBlank { url },
                url = url
            )
        )
    }

    suspend fun removeHistoryById(id: Long) {
        dao.deleteHistoryById(id)
    }

    suspend fun clearHistory() {
        dao.clearHistory()
    }

    // Downloads
    val downloads: Flow<List<DownloadItemEntity>> = dao.getAllDownloads()

    suspend fun addDownload(
        fileName: String,
        url: String,
        mimeType: String?,
        contentLength: Long
    ): Long {
        return dao.insertDownload(
            DownloadItemEntity(
                fileName = fileName,
                url = url,
                mimeType = mimeType,
                contentLength = contentLength
            )
        )
    }

    suspend fun removeDownloadById(id: Long) {
        dao.deleteDownloadById(id)
    }

    suspend fun clearDownloads() {
        dao.clearDownloads()
    }
}
