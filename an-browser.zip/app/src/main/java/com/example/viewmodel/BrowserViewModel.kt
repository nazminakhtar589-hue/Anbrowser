package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BookmarkEntity
import com.example.data.BrowserDatabase
import com.example.data.BrowserRepository
import com.example.data.DownloadItemEntity
import com.example.data.HistoryEntity
import com.example.model.BrowserTab
import com.example.model.QuickShortcut
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class BrowserPanel {
    NONE,
    TABS_SWITCHER,
    BOOKMARKS,
    HISTORY,
    DOWNLOADS,
    SETTINGS
}

sealed class WebCommand {
    data class LoadUrl(val tabId: String, val url: String) : WebCommand()
    data class GoBack(val tabId: String) : WebCommand()
    data class GoForward(val tabId: String) : WebCommand()
    data class Reload(val tabId: String) : WebCommand()
    data class StopLoading(val tabId: String) : WebCommand()
    data class FindInPage(val query: String) : WebCommand()
    data object FindNext : WebCommand()
    data object FindPrevious : WebCommand()
    data object ClearMatches : WebCommand()
}

class BrowserViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: BrowserRepository

    init {
        val db = BrowserDatabase.getDatabase(application)
        repository = BrowserRepository(db.browserDao())
    }

    // Tabs state
    private val initialTab = BrowserTab(url = "home", title = "New Tab")
    private val _tabs = MutableStateFlow<List<BrowserTab>>(listOf(initialTab))
    val tabs: StateFlow<List<BrowserTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow(initialTab.id)
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    // Active panel
    private val _activePanel = MutableStateFlow(BrowserPanel.NONE)
    val activePanel: StateFlow<BrowserPanel> = _activePanel.asStateFlow()

    // Find in page state
    private val _isFindInPageOpen = MutableStateFlow(false)
    val isFindInPageOpen: StateFlow<Boolean> = _isFindInPageOpen.asStateFlow()

    private val _findQuery = MutableStateFlow("")
    val findQuery: StateFlow<String> = _findQuery.asStateFlow()

    private val _findResult = MutableStateFlow(Pair(0, 0)) // current index, total count
    val findResult: StateFlow<Pair<Int, Int>> = _findResult.asStateFlow()

    // Settings
    private val _searchEngine = MutableStateFlow("Google") // Google, DuckDuckGo, Bing
    val searchEngine: StateFlow<String> = _searchEngine.asStateFlow()

    private val _themeMode = MutableStateFlow("System") // System, Light, Dark
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    // Web Commands to send to active WebView
    private val _webCommands = MutableSharedFlow<WebCommand>()
    val webCommands: SharedFlow<WebCommand> = _webCommands.asSharedFlow()

    // User Shortcuts
    private val _shortcuts = MutableStateFlow(QuickShortcut.defaultShortcuts)
    val shortcuts: StateFlow<List<QuickShortcut>> = _shortcuts.asStateFlow()

    // Database reactive streams
    val bookmarks: StateFlow<List<BookmarkEntity>> = repository.bookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<HistoryEntity>> = repository.history
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloads: StateFlow<List<DownloadItemEntity>> = repository.downloads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getActiveTab(): BrowserTab {
        val currentTabs = _tabs.value
        val activeId = _activeTabId.value
        return currentTabs.find { it.id == activeId } ?: currentTabs.firstOrNull() ?: initialTab
    }

    // Tab Operations
    fun createTab(url: String = "home", isIncognito: Boolean = false) {
        val newTab = BrowserTab(
            title = if (url == "home") (if (isIncognito) "Private Tab" else "New Tab") else "Loading...",
            url = url,
            isIncognito = isIncognito
        )
        _tabs.value = _tabs.value + newTab
        _activeTabId.value = newTab.id
        _activePanel.value = BrowserPanel.NONE
        if (url != "home") {
            viewModelScope.launch {
                _webCommands.emit(WebCommand.LoadUrl(newTab.id, url))
            }
        }
    }

    fun closeTab(tabId: String) {
        val currentTabs = _tabs.value
        if (currentTabs.size <= 1) {
            // If closing last tab, reset to a new Home tab
            val freshTab = BrowserTab(url = "home", title = "New Tab")
            _tabs.value = listOf(freshTab)
            _activeTabId.value = freshTab.id
            return
        }

        val index = currentTabs.indexOfFirst { it.id == tabId }
        val remaining = currentTabs.filter { it.id != tabId }
        _tabs.value = remaining

        if (_activeTabId.value == tabId) {
            val newIndex = index.coerceAtMost(remaining.size - 1)
            _activeTabId.value = remaining[newIndex].id
        }
    }

    fun switchTab(tabId: String) {
        _activeTabId.value = tabId
        _activePanel.value = BrowserPanel.NONE
    }

    fun closeAllTabs(incognitoOnly: Boolean = false) {
        val currentTabs = _tabs.value
        val remaining = if (incognitoOnly) {
            currentTabs.filter { !it.isIncognito }
        } else {
            emptyList()
        }

        if (remaining.isEmpty()) {
            val freshTab = BrowserTab(url = "home", title = "New Tab")
            _tabs.value = listOf(freshTab)
            _activeTabId.value = freshTab.id
        } else {
            _tabs.value = remaining
            if (remaining.none { it.id == _activeTabId.value }) {
                _activeTabId.value = remaining.first().id
            }
        }
        _activePanel.value = BrowserPanel.NONE
    }

    // Panel controls
    fun openPanel(panel: BrowserPanel) {
        _activePanel.value = if (_activePanel.value == panel) BrowserPanel.NONE else panel
    }

    fun closePanel() {
        _activePanel.value = BrowserPanel.NONE
    }

    // Navigation and URL loading
    fun loadUrl(rawInput: String, tabId: String? = null) {
        val targetTabId = tabId ?: _activeTabId.value
        val input = rawInput.trim()
        if (input.isBlank()) return

        val url = formatUrl(input)
        updateTab(targetTabId) {
            it.copy(
                url = url,
                title = if (url == "home") (if (it.isIncognito) "Private Tab" else "New Tab") else "Loading...",
                isLoading = url != "home",
                progress = 10
            )
        }

        if (url != "home") {
            viewModelScope.launch {
                _webCommands.emit(WebCommand.LoadUrl(targetTabId, url))
            }
        }
    }

    private fun formatUrl(input: String): String {
        if (input.equals("home", ignoreCase = true) || input.equals("about:blank", ignoreCase = true)) {
            return "home"
        }
        if (input.startsWith("http://", ignoreCase = true) || input.startsWith("https://", ignoreCase = true)) {
            return input
        }
        // If it looks like a domain name (no spaces, contains a dot)
        if (input.contains(".") && !input.contains(" ")) {
            return "https://$input"
        }
        // Search query based on selected engine
        val encodedQuery = java.net.URLEncoder.encode(input, "UTF-8")
        return when (_searchEngine.value) {
            "DuckDuckGo" -> "https://duckduckgo.com/?q=$encodedQuery"
            "Bing" -> "https://www.bing.com/search?q=$encodedQuery"
            else -> "https://www.google.com/search?q=$encodedQuery"
        }
    }

    fun reloadActiveTab() {
        val tab = getActiveTab()
        if (tab.url == "home") return
        viewModelScope.launch {
            _webCommands.emit(WebCommand.Reload(tab.id))
        }
    }

    fun stopActiveTabLoading() {
        val tab = getActiveTab()
        viewModelScope.launch {
            _webCommands.emit(WebCommand.StopLoading(tab.id))
        }
    }

    fun goBackActiveTab() {
        val tab = getActiveTab()
        viewModelScope.launch {
            _webCommands.emit(WebCommand.GoBack(tab.id))
        }
    }

    fun goForwardActiveTab() {
        val tab = getActiveTab()
        viewModelScope.launch {
            _webCommands.emit(WebCommand.GoForward(tab.id))
        }
    }

    fun goHomeActiveTab() {
        val tab = getActiveTab()
        updateTab(tab.id) {
            it.copy(
                url = "home",
                title = if (it.isIncognito) "Private Tab" else "New Tab",
                isLoading = false,
                progress = 0
            )
        }
    }

    fun toggleDesktopMode(tabId: String) {
        updateTab(tabId) {
            it.copy(isDesktopMode = !it.isDesktopMode)
        }
        reloadActiveTab()
    }

    fun toggleIncognitoForCurrentTab() {
        val current = getActiveTab()
        createTab(url = "home", isIncognito = !current.isIncognito)
    }

    // WebView event updates
    fun onPageStarted(tabId: String, url: String) {
        updateTab(tabId) {
            it.copy(
                url = url,
                isLoading = true,
                progress = 15
            )
        }
    }

    fun onPageFinished(tabId: String, url: String, canGoBack: Boolean, canGoForward: Boolean) {
        val tab = _tabs.value.find { it.id == tabId }
        val title = tab?.title?.ifBlank { url } ?: url
        updateTab(tabId) {
            it.copy(
                url = url,
                isLoading = false,
                progress = 100,
                canGoBack = canGoBack,
                canGoForward = canGoForward
            )
        }

        // Record history only if not incognito and not home
        if (tab != null && !tab.isIncognito && url != "home" && !url.startsWith("about:")) {
            viewModelScope.launch {
                repository.addHistory(title, url)
            }
        }
    }

    fun onProgressChanged(tabId: String, progress: Int) {
        updateTab(tabId) {
            it.copy(
                progress = progress,
                isLoading = progress < 100
            )
        }
    }

    fun onTitleReceived(tabId: String, title: String) {
        if (title.isNotBlank() && title != "about:blank") {
            updateTab(tabId) { it.copy(title = title) }
        }
    }

    private fun updateTab(tabId: String, transform: (BrowserTab) -> BrowserTab) {
        _tabs.value = _tabs.value.map { tab ->
            if (tab.id == tabId) transform(tab) else tab
        }
    }

    // Bookmarks management
    fun isCurrentPageBookmarked(url: String): Boolean {
        if (url == "home" || url.isBlank()) return false
        return bookmarks.value.any { it.url == url }
    }

    fun toggleBookmarkCurrentPage() {
        val tab = getActiveTab()
        if (tab.isHome) return

        viewModelScope.launch {
            val existing = bookmarks.value.find { it.url == tab.url }
            if (existing != null) {
                repository.removeBookmarkById(existing.id)
            } else {
                repository.addBookmark(tab.displayTitle, tab.url)
            }
        }
    }

    fun addBookmark(title: String, url: String) {
        viewModelScope.launch {
            repository.addBookmark(title, url)
        }
    }

    fun removeBookmark(id: Long) {
        viewModelScope.launch {
            repository.removeBookmarkById(id)
        }
    }

    // History management
    fun removeHistoryItem(id: Long) {
        viewModelScope.launch {
            repository.removeHistoryById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    // Downloads management
    fun recordDownload(fileName: String, url: String, mimeType: String?, contentLength: Long) {
        viewModelScope.launch {
            repository.addDownload(fileName, url, mimeType, contentLength)
        }
    }

    fun removeDownload(id: Long) {
        viewModelScope.launch {
            repository.removeDownloadById(id)
        }
    }

    fun clearAllDownloads() {
        viewModelScope.launch {
            repository.clearDownloads()
        }
    }

    // Find in page
    fun openFindInPage() {
        _isFindInPageOpen.value = true
        _findQuery.value = ""
        _findResult.value = Pair(0, 0)
    }

    fun closeFindInPage() {
        _isFindInPageOpen.value = false
        _findQuery.value = ""
        _findResult.value = Pair(0, 0)
        viewModelScope.launch {
            _webCommands.emit(WebCommand.ClearMatches)
        }
    }

    fun updateFindQuery(query: String) {
        _findQuery.value = query
        viewModelScope.launch {
            if (query.isNotBlank()) {
                _webCommands.emit(WebCommand.FindInPage(query))
            } else {
                _webCommands.emit(WebCommand.ClearMatches)
                _findResult.value = Pair(0, 0)
            }
        }
    }

    fun findNext() {
        viewModelScope.launch {
            _webCommands.emit(WebCommand.FindNext)
        }
    }

    fun findPrevious() {
        viewModelScope.launch {
            _webCommands.emit(WebCommand.FindPrevious)
        }
    }

    fun updateFindResult(activeMatchOrdinal: Int, numberOfMatches: Int) {
        _findResult.value = Pair(activeMatchOrdinal, numberOfMatches)
    }

    // Settings
    fun setSearchEngine(engine: String) {
        _searchEngine.value = engine
    }

    fun setThemeMode(mode: String) {
        _themeMode.value = mode
    }

    // Custom shortcuts
    fun addShortcut(title: String, url: String) {
        val formatted = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val newShortcut = QuickShortcut(
            id = System.currentTimeMillis().toString(),
            title = title.ifBlank { formatted },
            url = formatted,
            iconLetter = title.firstOrNull()?.uppercase() ?: "W",
            colorHex = 0xFF1A73E8
        )
        _shortcuts.value = _shortcuts.value + newShortcut
    }

    fun removeShortcut(id: String) {
        _shortcuts.value = _shortcuts.value.filter { it.id != id }
    }
}
